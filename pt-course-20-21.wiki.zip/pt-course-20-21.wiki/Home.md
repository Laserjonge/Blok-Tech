👋

This is an example wiki for blok tech. This is **not a template** but more of a blueprint. It will get you up and running quickly with the minimum requirements for your documentation but don't take it _as is_. Add more topics and pages once you get going.

We highly recommend you [clone this wiki](https://docs.github.com/en/github/building-a-strong-community/adding-or-editing-wiki-pages#adding-or-editing-wiki-pages-locally) to your local machine with and write markdown with the comfort of your code editor instead of editing straight in the browser.

You can edit the `_Sidebar.md_` file to create a custom table of contents. You can update your personal information in the `_Footer.md_`.

> Make sure you also edit the paths to the corrent page in your _Sidebar component